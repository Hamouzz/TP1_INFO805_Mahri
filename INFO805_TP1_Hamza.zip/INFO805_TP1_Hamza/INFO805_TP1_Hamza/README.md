# TP1 Compilation

Haris Coliche
Clément de Louvencourt

Pour éxécuter le TP :
```
gradle build
java -jar Exercice2/build/libs/Exercice1.jar tpEvaluateurSource.txt
java -jar Exercice2/build/libs/Exercice2.jar tpEvaluateurSource.txt
```